var searchData=
[
  ['move',['move',['../classmain_1_1Ball.html#a3cf96055be08617f5163593558080c8a',1,'main.Ball.move()'],['../classmain_1_1Paddle.html#af5670b15b76dca1c142016a67703f5a0',1,'main.Paddle.move()']]]
];
