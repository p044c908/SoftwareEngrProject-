var indexSectionsWithContent =
{
  0: "_bcdmp",
  1: "bp",
  2: "_cdm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

