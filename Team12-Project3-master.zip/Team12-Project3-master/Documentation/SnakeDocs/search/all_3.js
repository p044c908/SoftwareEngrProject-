var searchData=
[
  ['move',['move',['../classsnake_1_1Snake.html#a36b5f69ce5fa3f672aa3a778012f49c6',1,'snake::Snake']]],
  ['movement',['movement',['../classsnake_1_1Snake.html#a3e793ccf974978c39a4f8375ee8e91e6',1,'snake::Snake']]]
];
