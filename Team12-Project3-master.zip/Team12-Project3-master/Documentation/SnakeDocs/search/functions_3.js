var searchData=
[
  ['randompos',['randomPos',['../classfood_1_1Food.html#af45703903b8b034d72b6c141f0d97ec2',1,'food::Food']]],
  ['reset',['reset',['../classsnake_1_1Snake.html#a13937ea70d91babf12a5237d4fa5c265',1,'snake::Snake']]]
];
