var searchData=
[
  ['turn',['turn',['../classsnake_1_1Snake.html#a045f212ea248caefb132a9e41877c140',1,'snake::Snake']]]
];
