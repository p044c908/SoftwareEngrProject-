var searchData=
[
  ['eliminate',['eliminate',['../classGame_1_1Game.html#a9e327a4d999fb7a1ca0cd247b7890d43',1,'Game::Game']]]
];
