var searchData=
[
  ['moveleft',['moveLeft',['../classGame_1_1Game.html#a08ace6b3a3afb2abe67381b2dc178950',1,'Game::Game']]],
  ['moveright',['moveRight',['../classGame_1_1Game.html#a5a703f353507672dabb44cf780e38a57',1,'Game::Game']]]
];
