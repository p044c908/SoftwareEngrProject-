var searchData=
[
  ['rotate',['rotate',['../classBlocks_1_1Figure.html#afdec9b648911eacf8ce1a9f5ecb9dd5d',1,'Blocks.Figure.rotate()'],['../classGame_1_1Game.html#a7ea104d6680e13419ac37a0a69a19d86',1,'Game.Game.rotate()']]]
];
