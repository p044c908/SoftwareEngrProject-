var searchData=
[
  ['shape',['shape',['../classBlocks_1_1Figure.html#a32c6e9667627a817f0554cb9da8a5c87',1,'Blocks::Figure']]],
  ['start',['Start',['../classGame_1_1Game.html#a1d7f0dc35e4e8c7a2dfc4f33f9c6bdbf',1,'Game::Game']]]
];
